import logging
from fromText import smartBrakeConfig_v2_pb2
from confluent_kafka import Consumer, Producer
from google.protobuf.json_format import ParseDict
from confluent_kafka.serialization import StringSerializer
from uuid import uuid4
import json
import time


def encodeprotobuf_logic(topic, consumer_conf, topic_proto, producer_proto):
    try:
        consumer = Consumer(consumer_conf)
        consumer.close()
    except:
        pass

    consumer = Consumer(consumer_conf)

    logging.info(f"Subscribing to topic: {topic}")
    consumer.subscribe([topic])

    ### Get Producer
    #logging.info(f"Getting producer.")

    string_serializer = StringSerializer("utf_8")

    ### Consume Protobuf data
    while True:
        try:
            # SIGINT can't be handled when polling, limit timeout to 1 second.
            msg = consumer.poll(20.0)
            if msg is None:
                break
                # continue
            value = msg.value()

            # json_data = json.dump(value.decode('utf-8'))
            json_dict = json.loads(value.decode("utf-8"))
            logging.info(f"Read json fom kafka topic: {json_dict}")
            key = msg.key()
            if key != None:
                key = key.decode('utf-8')
            else:
                key = str(uuid4())

            msgv2 = smartBrakeConfig_v2_pb2.SmbxConfig()
            value = ParseDict(json_dict, msgv2)

            try:
                msgv2.timestamp = json_dict["timestamp"]
            except:
                msgv2.timestamp = round(time.time() * 1000)

            try:
                msgv2.configVersion = json_dict["configVersion"]
            except:
                msgv2.configVersion = 0
            try:
                msgv2.telemetrySamplingInterval = json_dict["telemetrySamplingInterval"]
            except:
                msgv2.telemetrySamplingInterval = 0

            try:
                msgv2.impactSamplingRate = json_dict["impactSamplingRate"]
            except:
                msgv2.impactSamplingRate = 0

            try:
                msgv2.regularDataTransferInterval = json_dict[
                    "regularDataTransferInterval"
                ]
            except:
                msgv2.regularDataTransferInterval = 0

            try:
                msgv2.highResolutionImpactSensorThreshold = json_dict[
                    "highResolutionImpactSensorThreshold"
                ]
            except:
                msgv2.highResolutionImpactSensorThreshold = 0

            try:
                msgv2.cloudConfiguration.projectId = json_dict["cloudConfiguration"][
                    "projectId"
                ]
            except:
                msgv2.cloudConfiguration.projectId = "None"

            try:
                msgv2.cloudConfiguration.region = json_dict["cloudConfiguration"][
                    "region"
                ]
            except:
                msgv2.cloudConfiguration.region = "None"

            try:
                msgv2.cloudConfiguration.registryId = json_dict["cloudConfiguration"][
                    "registryId"
                ]
            except:
                msgv2.cloudConfiguration.registryId = "None"

            try:
                msgv2.cloudConfiguration.mqttHost = json_dict["cloudConfiguration"][
                    "mqttHost"
                ]
            except:
                msgv2.cloudConfiguration.mqttHost = "None"

            try:
                msgv2.cloudConfiguration.mqttPort = json_dict["cloudConfiguration"][
                    "mqttPort"
                ]
            except:
                msgv2.cloudConfiguration.mqttPort = "None"

            try:
                msgv2.cloudConfiguration.ntpHost = json_dict["cloudConfiguration"][
                    "ntpHost"
                ]
            except:
                msgv2.cloudConfiguration.ntpHost = "None"

            message = msgv2.SerializeToString()
            produce(message, producer_proto, topic_proto, key)

        except KeyboardInterrupt:
            break

    consumer.close()


def produce(data, producer, topic_proto, key):
    string_serializer = StringSerializer("utf_8")
    #topic_proto = "devices_config_protobuf"

    ### Produce Json data
    while True:
        # Serve on_delivery callbacks from previous calls to produce()
        producer.poll(0.0)
        try:
            producer.produce(
                topic=topic_proto,
                key=string_serializer(key),
                value=data,
                on_delivery=delivery_report,
            )
            break
        except KeyboardInterrupt:
            break
        except ValueError:
            logging.info("Invalid input, discarding record...")
            continue

    logging.info("Flushing records...")
    producer.flush()


def delivery_report(err, msg):
    """
    Reports the failure or success of a message delivery.

    Args:
        err (KafkaError): The error that occurred on None on success.
        msg (Message): The message that was produced or failed.
    """

    if err is not None:
        logging.info("Delivery failed for User record {}: {}".format(msg.key(), err))
        return
    logging.info(
        "User record {} successfully produced to {} [{}] at offset {}".format(
            msg.key(), msg.topic(), msg.partition(), msg.offset()
        )
    )
