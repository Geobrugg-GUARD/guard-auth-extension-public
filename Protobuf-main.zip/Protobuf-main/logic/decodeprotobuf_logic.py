import logging
from fromText import smartBrakeMessages_v2_pb2
from confluent_kafka import Consumer, Producer
from google.protobuf.json_format import MessageToJson
from confluent_kafka.serialization import StringSerializer
from uuid import uuid4
import json


def decodeprotobuf_logic(topic, consumer_conf, producer_json, topic_impact, topic_telemetry):
    try:
        consumer = Consumer(consumer_conf)
        consumer.close()
    except:
        pass

    consumer = Consumer(consumer_conf)

    logging.info(f"Subscribing to topic: {topic}")
    consumer.subscribe([topic])

    ### Get Producer
    logging.info(f"Getting producer.")

    # topic_json = "devices_json"

    # string_serializer = StringSerializer("utf_8")

    ### Consume Protobuf data
    while True:
        is_protobuf = False
        try:
            # SIGINT can't be handled when polling, limit timeout to 1 second.
            msg = consumer.poll(20.0)
            if msg is None:
                break
                # continue
            value = msg.value()
            key = msg.key()

            try:
                msgv2 = smartBrakeMessages_v2_pb2.SmbxTelemetry()
                msgv2.ParseFromString(value)
                json_data = MessageToJson(msgv2,float_precision=17) #,float_precision=17
                json_dict = json.loads(json_data)
                json_dict["topic"] = msg.key().decode("utf-8")
                if len(json_dict.keys()) < 3:
                    is_protobuf = True
                    pass
                else:
                    json_data = json.dumps(json_dict)
                    produce(json_data, producer_json, topic_telemetry)
                    is_protobuf = True
            except:
                pass

            try:
                msgv2 = smartBrakeMessages_v2_pb2.SmbxImpact()
                msgv2.ParseFromString(value)
                json_data = MessageToJson(msgv2,float_precision=17)
                json_dict = json.loads(json_data)
                json_dict["topic"] = msg.key().decode("utf-8")
                if len(json_dict.keys()) < 3:
                    is_protobuf = True
                    pass
                else:
                    json_data = json.dumps(json_dict)
                    produce(json_data, producer_json, topic_impact)
                    is_protobuf = True
            except:
                pass


            '''
            ### Only use if needed in future
            
            try:
                msgv2 = smartBrakeMessages_v2_pb2.Samples()
                msgv2.ParseFromString(value)
                json_data = MessageToJson(msgv2)
                json_dict = json.loads(json_data)
                json_dict["topic"] = msg.key().decode("utf-8")
                json_data = json.dumps(json_dict)
                produce(json_data, producer_json, topic_json)
                is_protobuf = True
            except:
                pass

            try:
                msgv2 = smartBrakeMessages_v2_pb2.AccelerationSample()
                msgv2.ParseFromString(value)
                json_data = MessageToJson(msgv2)
                json_dict = json.loads(json_data)
                json_dict["topic"] = msg.key().decode("utf-8")
                json_data = json.dumps(json_dict)
                produce(json_data, producer_json, topic_json)
                is_protobuf = True
            except:
                pass

            try:
                msgv2 = smartBrakeMessages_v2_pb2.RepeatedAccelerationSamples()
                msgv2.ParseFromString(value)
                json_data = MessageToJson(msgv2)
                json_dict = json.loads(json_data)
                json_dict["topic"] = msg.key().decode("utf-8")
                json_data = json.dumps(json_dict)
                produce(json_data, producer_json, topic_json)
                is_protobuf = True
            except:
                pass

            try:
                msgv2 = smartBrakeMessages_v2_pb2.SmbxPicture()
                msgv2.ParseFromString(value)
                json_data = MessageToJson(msgv2)
                json_dict = json.loads(json_data)
                json_dict["topic"] = msg.key().decode("utf-8")
                json_data = json.dumps(json_dict)
                produce(json_data, producer_json, topic_json)
                is_protobuf = True
            except:
                pass
            '''

            if is_protobuf == False:
                json_data = value.decode("utf-8", errors="ignore")
                produce(json_data, producer_json, topic_impact)
                produce(json_data, producer_json, topic_telemetry)

            logging.info(f"JSON was consumed: {json_data}.\nProducing JSON data now.")

        except KeyboardInterrupt:
            break

    consumer.close()


def produce(json_data, producer, topic_json):
    string_serializer = StringSerializer("utf_8")

    ### Produce Json data
    while True:
        # Serve on_delivery callbacks from previous calls to produce()
        producer.poll(0.0)
        try:
            producer.produce(
                topic=topic_json,
                key=string_serializer(str(uuid4())),
                value=string_serializer(json_data),
                on_delivery=delivery_report,
            )
            break
        except KeyboardInterrupt:
            break
        except ValueError:
            logging.info("Invalid input, discarding record...")
            continue

    logging.info("Flushing records...")
    producer.flush()


def delivery_report(err, msg):
    """
    Reports the failure or success of a message delivery.

    Args:
        err (KafkaError): The error that occurred on None on success.
        msg (Message): The message that was produced or failed.
    """

    if err is not None:
        logging.info("Delivery failed for User record {}: {}".format(msg.key(), err))
        return
    logging.info(
        "User record {} successfully produced to {} [{}] at offset {}".format(
            msg.key(), msg.topic(), msg.partition(), msg.offset()
        )
    )
