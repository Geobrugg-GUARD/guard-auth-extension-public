import logging
from azure.functions import KafkaEvent
from uuid import uuid4
import os
from logic.decodeprotobuf_logic import decodeprotobuf_logic
from confluent_kafka import Producer


# def main(req: func.HttpRequest) -> func.HttpResponse:
def main(kevents):
    logging.info("Kafka event was triggered.")

    ### Get Consumer
    topic = "devices"
    client = uuid4()
    consumer_conf = {
        "bootstrap.servers": os.environ["CONFLUENT_BOOTSTRAP_SERVER_PROD"],
        "group.id": "itn95",
        "client.id": client,
        "session.timeout.ms": "45000",
        "heartbeat.interval.ms": "500",
        "enable.auto.commit": "True",
        "auto.offset.reset": "earliest",
        "security.protocol": "SASL_SSL",
        "sasl.mechanism": "PLAIN",
        "sasl.username": os.environ["CONFLUENT_API_KEY"],
        "sasl.password": os.environ["CONFLUENT_API_SECRET"],
    }

    topic_impact = 'devices_impact'
    topic_telemetry = 'devices_telemetry'

    producer_json = Producer(
        {
            "bootstrap.servers": os.environ["CONFLUENT_BOOTSTRAP_SERVER_PROD"],
            "security.protocol": "SASL_SSL",
            "sasl.mechanism": "PLAIN",
            "sasl.username": os.environ["CONFLUENT_API_KEY"],
            "sasl.password": os.environ["CONFLUENT_API_SECRET"],
        }
    )

    decodeprotobuf_logic(topic, consumer_conf, producer_json, topic_impact, topic_telemetry)
