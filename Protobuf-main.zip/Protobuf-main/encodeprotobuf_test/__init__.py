import logging
from azure.functions import KafkaEvent
from uuid import uuid4
import os
from logic.encodeprotobuf_logic import encodeprotobuf_logic
from confluent_kafka import Producer


def main(kevents):
    logging.info("Kafka event was triggered.")

    ### Get Consumer
    topic = "devices_config"
    client = uuid4()
    consumer_conf = {
        "bootstrap.servers": os.environ["CONFLUENT_BOOTSTRAP_SERVER_TEST"],
        "group.id": "itn20",
        "client.id": client,
        "session.timeout.ms": "45000",
        "heartbeat.interval.ms": "500",
        "enable.auto.commit": "True",
        "auto.offset.reset": "earliest",
        "security.protocol": "SASL_SSL",
        "sasl.mechanism": "PLAIN",
        "sasl.username": os.environ["CONFLUENT_API_KEY_TEST"],
        "sasl.password": os.environ["CONFLUENT_API_SECRET_TEST"],
    }

    topic_proto = "devices_config_protobuf"
    
    producer_proto = Producer(
        {
            "bootstrap.servers": os.environ["CONFLUENT_BOOTSTRAP_SERVER_TEST"],
            "security.protocol": "SASL_SSL",
            "sasl.mechanism": "PLAIN",
            "sasl.username": os.environ["CONFLUENT_API_KEY_TEST"],
            "sasl.password": os.environ["CONFLUENT_API_SECRET_TEST"],
        }
    )

    encodeprotobuf_logic(topic, consumer_conf, topic_proto, producer_proto)
